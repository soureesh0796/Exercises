package com.hotel.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Room {
	
	@Id
	private int ro_id;
	private int ro_number;
	public int getRo_id() {
		return ro_id;
	}
	public void setRo_id(int ro_id) {
		this.ro_id = ro_id;
	}
	
	public int getRo_number() {
		return ro_number;
	}
	public void setRo_number(int ro_number) {
		this.ro_number = ro_number;
	}
	public Room() {
		super();
	}
	public Room(int ro_id, int ro_number) {
		super();
		this.ro_id = ro_id;
		this.ro_number = ro_number;
	}


}
