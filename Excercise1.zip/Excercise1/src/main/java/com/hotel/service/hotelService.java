package com.hotel.service;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import com.hotel.model.Room;
import com.hotel.model.RoomBlocking;

public interface hotelService {
	
	public List<Room> getRooms();

	public void booking(Date date, int room_no);

	public boolean validate(int room_no, Date date) throws ParseException;

	public Room getRoomDetails(int room_no);

	public List<RoomBlocking> getRoomBooking(int ro_id);

	public void toggle(Integer id) throws ParseException;

}
