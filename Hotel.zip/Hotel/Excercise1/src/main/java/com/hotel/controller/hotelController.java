package com.hotel.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hotel.model.Room;
import com.hotel.model.RoomBlocking;
import com.hotel.service.hotelService;

@Controller
public class hotelController {

	@Autowired(required = true)
	private hotelService service;

	@RequestMapping(value = "/")
	private String home(Model model) {
		/*
		 * List<Room> roomList=service.getRooms(); model.addAttribute("RoomList",
		 * roomList);
		 */
		return "Calendar";
	}



	@PostMapping(value = "/getDetails")
	public String getDetails(Model model, HttpServletRequest request) {
		System.out.println(request.getParameter("number"));
		Integer room_no = Integer.parseInt(request.getParameter("number"));
		Room room = service.getRoomDetails(room_no);
		List<RoomBlocking> blocked = service.getRoomBooking(room.getRo_id());
		model.addAttribute("roomInfo", "rmInfo");
		// request.setAttribute("roomList", blocked);
		model.addAttribute("roomList", blocked);
		System.out.println(blocked.size() + "size of jkln");

		return "Calendar";
	}

	@RequestMapping(value = "/bookingToggle")
	public String bookingToggle(Model model, HttpServletRequest request) throws ParseException {
		
		int id=Integer.parseInt(request.getParameter("id"));
		System.out.println("booking id is "+id);
		service.toggle(id);
		System.out.println("id of the booking is :"+id);
		return "Calendar";

	}

}
