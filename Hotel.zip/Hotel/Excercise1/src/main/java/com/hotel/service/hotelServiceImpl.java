package com.hotel.service;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.dao.hotelDao;
import com.hotel.model.Room;
import com.hotel.model.RoomBlocking;

@Service("service")
public class hotelServiceImpl implements hotelService {

	@Autowired
	private hotelDao dao;
	
	@Override
	@Transactional
	public List<Room> getRooms() {
		// TODO Auto-generated method stub
		List<Room> roomList=dao.getRooms();
		return roomList;
	}

	@Override
	@Transactional
	public void booking(Date date, int room_no) {
		// TODO Auto-generated method stub
		dao.booking(date,room_no);
		
	}

	@Override
	public boolean validate(int room_no, Date date) throws ParseException {
		// TODO Auto-generated method stub
		if(dao.validate(room_no,date))
		{
			return true;
		}
		return false;
	}

	@Override
	public Room getRoomDetails(int room_no) {
		// TODO Auto-generated method stub
		Room room=dao.getRoomDetails(room_no);
		return room;
	}

	@Override
	public List<RoomBlocking> getRoomBooking(int ro_id) {
		// TODO Auto-generated method stub
		List<RoomBlocking> list=dao.getRoomBooking(ro_id);
		return list;
	}

	@Override
	@Transactional
	public void toggle(Integer id) throws ParseException {
		// TODO Auto-generated method stub
		System.out.println("inside service");
		dao.toggle(id);
		
	}

	

	

}
