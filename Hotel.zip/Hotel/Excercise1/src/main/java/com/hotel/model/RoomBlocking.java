package com.hotel.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Room_Blocking")
public class RoomBlocking {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int RB_ID;
	@ManyToOne
	private Room room;
	private Date RO_DATE;
	private String RB_BOOKED;
	public int getRB_ID() {
		return RB_ID;
	}
	public void setRB_ID(int rB_ID) {
		RB_ID = rB_ID;
	}
	public Room getRoom() {
		return room;
	}
	public void setRoom(Room room) {
		this.room = room;
	}
	public Date getRO_DATE() {
		return RO_DATE;
	}
	public void setRO_DATE(Date rO_DATE) {
		RO_DATE = rO_DATE;
	}
	public String getRB_BOOKED() {
		return RB_BOOKED;
	}
	public void setRB_BOOKED(String rB_BOOKED) {
		RB_BOOKED = rB_BOOKED;
	}
	public RoomBlocking(int rB_ID, Room room, Date rO_DATE, String rB_BOOKED) {
		super();
		RB_ID = rB_ID;
		this.room = room;
		RO_DATE = rO_DATE;
		RB_BOOKED = rB_BOOKED;
	}
	public RoomBlocking() {
		super();
	}
	
	

}
