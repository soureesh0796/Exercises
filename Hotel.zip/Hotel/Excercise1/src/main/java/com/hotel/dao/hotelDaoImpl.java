package com.hotel.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hotel.model.Room;
import com.hotel.model.RoomBlocking;
@Repository("dao")
public class hotelDaoImpl implements hotelDao {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public List<Room> getRooms() {
		Query query=em.createQuery("from Room",Room.class);
		List<Room> roomList=(List<Room>)query.getResultList();
		return roomList;
	}

	@Override
	public void booking(Date date, int room_no) {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Room room=em.find(Room.class, room_no);
		RoomBlocking booking=new RoomBlocking();
		booking.setRO_DATE(date);
		booking.setRoom(room);
		booking.setRB_BOOKED("Y");
		em.persist(booking);
		
	}

	@Override
	public boolean validate(int room_no, Date date) throws ParseException {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Query query=em.createQuery("from RoomBlocking",RoomBlocking.class);
		List<RoomBlocking> blockedrooms=query.getResultList();
		if(blockedrooms.isEmpty())
		{
			return true;
		}
		else
		{
			for(RoomBlocking r:blockedrooms)
			{
				
				System.out.println(sdf.format(date).equals(sdf.format(r.getRO_DATE())));
				System.out.println(r.getRoom().getRo_number()==room_no);
				if(sdf.format(date).equals(sdf.format(r.getRO_DATE())) && r.getRoom().getRo_number()==room_no)
				{
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public Room getRoomDetails(int room_no) {
		// TODO Auto-generated method stub
		Room room=em.find(Room.class, room_no);
		return room;
	}

	@Override
	public List<RoomBlocking> getRoomBooking(int ro_id) {
		// TODO Auto-generated method stub
		Query query=em.createQuery("from RoomBlocking",RoomBlocking.class);
		List<RoomBlocking> blockedrooms=query.getResultList();
		List<RoomBlocking> list=new ArrayList<RoomBlocking>();
		for(RoomBlocking r:blockedrooms)
		{
			if(r.getRoom().getRo_id()==ro_id)
				list.add(r);
		}
		System.out.println(list.size()+"size of list");
		return list;
	}

	@Override
	public void toggle(Integer id) throws ParseException {
		// TODO Auto-generated method stub
		System.out.println("inside dao");
		RoomBlocking rb=em.find(RoomBlocking.class, id);
		if(rb.getRB_BOOKED().equals("Y"))
		{
			rb.setRB_BOOKED("N");
			em.persist(rb);
		}
		else
		{
			rb.setRB_BOOKED("Y");
			em.persist(rb);
		}
		
	}

}
