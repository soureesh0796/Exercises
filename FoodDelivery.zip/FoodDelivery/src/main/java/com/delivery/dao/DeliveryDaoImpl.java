package com.delivery.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.delivery.model.Item;

@Repository
public class DeliveryDaoImpl implements DeliveryDao{
	
	@Autowired
	ItemRepository itemRep;

	@Override
	public List<Item> listItems() {
		List<Item> itemList=new ArrayList<>();
		itemRep.findAll().forEach(itemList::add);
		return itemList;
	}

}
