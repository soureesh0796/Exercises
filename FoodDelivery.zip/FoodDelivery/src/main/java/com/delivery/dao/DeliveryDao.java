package com.delivery.dao;

import java.util.List;

import com.delivery.model.Item;

public interface DeliveryDao {

	List<Item> listItems();

}
