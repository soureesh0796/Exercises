package com.delivery.service;

import java.util.List;

import com.delivery.model.Item;

public interface DeliveryService {

	List<Item> listItems();

}
