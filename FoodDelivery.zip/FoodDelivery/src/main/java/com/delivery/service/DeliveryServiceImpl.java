package com.delivery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.delivery.dao.DeliveryDao;
import com.delivery.model.Item;

@Service("deliveryService")
public class DeliveryServiceImpl implements DeliveryService{
	
	@Autowired(required=true)
	private DeliveryDao deliveryDao;

	@Override
	public List<Item> listItems() {
		List<Item> itemList=deliveryDao.listItems();
		return itemList;
	}

}
