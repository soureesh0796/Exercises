package com.delivery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.delivery.model.Item;
import com.delivery.service.DeliveryService;

@Controller
public class DeliveryController {
	
	@Autowired(required=true)
	private DeliveryService deliveryService;
	
	@GetMapping("/")
	public String homePage() {
		return "Welcome";
	}
	
	@RequestMapping("/listItems")
	public String listItems(Model model){
		List<Item> itemList=deliveryService.listItems();
		model.addAttribute("itemList",itemList);
		return "Menu";
	}
	
	@PostMapping("/placeOrder")
	public @ResponseBody String calculateCost(@RequestParam int id1, @RequestParam int id2){
		int cost=deliveryService.calculateCost(id1,id2);
		return Integer.toString(cost);
	}
	

}
